package com.techmania.quizgame

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.techmania.quizgame.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var mainBinding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Properly inflate and set the content view
        mainBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(mainBinding.root)

        mainBinding.buttonStartQuiz.setOnClickListener {
            val intent=Intent(this,QuizActivity::class.java)
            startActivity(intent)
        }

        // Set the click listener for the sign-out button
        mainBinding.buttonSignOut.setOnClickListener{

            //email and password
            FirebaseAuth.getInstance().signOut()
            //google account
            val gso= GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail().build()
            val googleSignInClient= GoogleSignIn.getClient(this,gso)
            googleSignInClient.signOut().addOnCompleteListener {
                task->
                if (task.isSuccessful){
                    Toast.makeText(applicationContext,"Sign Out is Successful",Toast.LENGTH_SHORT).show()
                }
            }



            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish() // Close MainActivity
        }
    }
}
