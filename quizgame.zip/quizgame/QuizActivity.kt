package com.techmania.quizgame

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.techmania.quizgame.databinding.ActivityQuizBinding
import kotlin.random.Random

class QuizActivity : AppCompatActivity() {
    private lateinit var quizBinding: ActivityQuizBinding

    // Initialize Firebase Database
    private val database = FirebaseDatabase.getInstance()
    private val databaseReference = database.reference.child("questions")

    private var question = ""
    private var answerA = ""
    private var answerB = ""
    private var answerC = ""
    private var answerD = ""
    private var correctAnswer = ""
    private var questionCount = 0
    private var questionNumber = 0

    var userAnswer = ""
    var userCorrect = 0
    var userWrong = 0

    lateinit var timer: CountDownTimer
    private val totalTime =25000L
    var timeContinue = false
    var timeLeft = totalTime
    val auth = FirebaseAuth.getInstance()
    val user = auth.currentUser
    val scoreRef= database.reference
    val questions= HashSet<Int>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        quizBinding = ActivityQuizBinding.inflate(layoutInflater)
        setContentView(quizBinding.root)

        do{

            val number= Random.nextInt(1,41)
            Log.d("number",number.toString())
            questions.add(number)
            }while (questions.size<5)
            Log.d("numberOfQuestions",questions.toString())



        // Set initial visibility for loading
        quizBinding.progressBarQuiz.visibility = android.view.View.VISIBLE
        quizBinding.linearLayoutInfo.visibility = android.view.View.INVISIBLE
        quizBinding.linearLayoutQuestion.visibility = android.view.View.INVISIBLE
        quizBinding.linearLayoutButtons.visibility = android.view.View.INVISIBLE

        // Load the first question
        loadQuestion()

        // Set up click listener for the Next button
        quizBinding.buttonNext.setOnClickListener {
            resetTimer()
            loadQuestion()
        }

        // Finish button click listener
        quizBinding.buttonFinish.setOnClickListener {
            sendScore()
        }
        // Set up click listeners for answer buttons
        quizBinding.textViewA.setOnClickListener {
            pauseTimer()
            userAnswer = "a"
            if (correctAnswer==userAnswer){
                quizBinding.textViewA.setBackgroundColor(Color.GREEN)
                userCorrect++
                quizBinding.textViewCorrect.text = userCorrect.toString()
            }else{
                quizBinding.textViewA.setBackgroundColor(Color.RED)
                userWrong++
                quizBinding.textViewWrong.text = userWrong.toString()
                findAnswer()

            }
            disableClickableOfOptions()

        }
        quizBinding.textViewB.setOnClickListener {
            pauseTimer()
            userAnswer = "b"
            if (correctAnswer==userAnswer){
                quizBinding.textViewB.setBackgroundColor(Color.GREEN)
                userCorrect++
                quizBinding.textViewCorrect.text = userCorrect.toString()
            }else{
                quizBinding.textViewB.setBackgroundColor(Color.RED)
                userWrong++
                quizBinding.textViewWrong.text = userWrong.toString()
                findAnswer()

            }
            disableClickableOfOptions()

        }
        quizBinding.textViewC.setOnClickListener {
            pauseTimer()
            userAnswer = "c"
            if (correctAnswer==userAnswer){
                quizBinding.textViewC.setBackgroundColor(Color.GREEN)
                userCorrect++
                quizBinding.textViewCorrect.text = userCorrect.toString()
            }else{
                quizBinding.textViewC.setBackgroundColor(Color.RED)
                userWrong++
                quizBinding.textViewWrong.text = userWrong.toString()
                findAnswer()

            }
            disableClickableOfOptions()

        }
        quizBinding.textViewD.setOnClickListener {
            pauseTimer()
            userAnswer = "d"
            if (correctAnswer==userAnswer){
                quizBinding.textViewD.setBackgroundColor(Color.GREEN)
                userCorrect++
                quizBinding.textViewCorrect.text = userCorrect.toString()
            }else{
                quizBinding.textViewD.setBackgroundColor(Color.RED)
                userWrong++
                quizBinding.textViewWrong.text = userWrong.toString()
                findAnswer()

            }
            disableClickableOfOptions()

        }
    }

    private fun loadQuestion() {
        restoreOptions()
        databaseReference.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                questionCount = snapshot.childrenCount.toInt()

                if (questionNumber < questions.size) {
                    // Retrieve question data from the database
                    question = snapshot.child(questions.elementAt(questionNumber).toString()).child("q").value.toString()
                    answerA = snapshot.child(questions.elementAt(questionNumber).toString()).child("a").value.toString()
                    answerB = snapshot.child(questions.elementAt(questionNumber).toString()).child("b").value.toString()
                    answerC = snapshot.child(questions.elementAt(questionNumber).toString()).child("c").value.toString()
                    answerD = snapshot.child(questions.elementAt(questionNumber).toString()).child("d").value.toString()
                    correctAnswer = snapshot.child(questions.elementAt(questionNumber).toString()).child("answer").value.toString()

                    // Update UI with question data and ensure all views are visible
                    runOnUiThread {
                        quizBinding.textViewQuestion.text = question
                        quizBinding.textViewA.text = answerA
                        quizBinding.textViewB.text = answerB
                        quizBinding.textViewC.text = answerC
                        quizBinding.textViewD.text = answerD

                        // Set visibility for all elements
                        quizBinding.progressBarQuiz.visibility = android.view.View.INVISIBLE
                        quizBinding.linearLayoutInfo.visibility = android.view.View.VISIBLE
                        quizBinding.linearLayoutQuestion.visibility = android.view.View.VISIBLE
                        quizBinding.linearLayoutButtons.visibility = android.view.View.VISIBLE

                        // Set visibility for text views in the linearLayoutInfo
                        quizBinding.textView5.visibility = android.view.View.VISIBLE
                        quizBinding.textViewTime.visibility = android.view.View.VISIBLE
                        quizBinding.textView3.visibility = android.view.View.VISIBLE
                        quizBinding.textViewCorrect.visibility = android.view.View.VISIBLE
                        quizBinding.textView.visibility = android.view.View.VISIBLE
                        quizBinding.textViewWrong.visibility = android.view.View.VISIBLE

                        // Set visibility for text views in the linearLayoutQuestion
                        quizBinding.textViewQuestion.visibility = android.view.View.VISIBLE
                        quizBinding.textViewA.visibility = android.view.View.VISIBLE
                        quizBinding.textViewB.visibility = android.view.View.VISIBLE
                        quizBinding.textViewC.visibility = android.view.View.VISIBLE
                        quizBinding.textViewD.visibility = android.view.View.VISIBLE

                        // Set visibility for buttons
                        quizBinding.buttonFinish.visibility = android.view.View.VISIBLE
                        quizBinding.buttonNext.visibility = android.view.View.VISIBLE
                    }

                    // Confirmation toast for debugging
                    Toast.makeText(this@QuizActivity, "Loaded question $questionNumber", Toast.LENGTH_SHORT).show()
                    startTimer()
                } else {
                    // All questions answered
                    runOnUiThread {
                        val dialogMessage = AlertDialog.Builder(this@QuizActivity)
                        dialogMessage.setTitle("Quiz Game")
                        dialogMessage.setMessage("Congratulation!!!\nYou answered all the questions. Do you want to see the result?")
                        dialogMessage.setCancelable(false)
                        dialogMessage.setPositiveButton("See Result"){dialogWindow,position ->
                            sendScore()
                        }
                        dialogMessage.setNegativeButton("Play Again"){dialogWindow,position ->
                            val intent = Intent(this@QuizActivity, MainActivity::class.java)
                            startActivity(intent)
                            finish()
                        }
                        dialogMessage.create().show()


                        }


                        quizBinding.progressBarQuiz.visibility = android.view.View.INVISIBLE
                    }


                questionNumber++ // Move to the next question
            }

            override fun onCancelled(error: DatabaseError) {
                runOnUiThread {
                    Toast.makeText(applicationContext, error.message, Toast.LENGTH_SHORT).show()
                }
            }
        })
    }
    fun findAnswer() {
        when(correctAnswer){
            "a"-> quizBinding.textViewA.setBackgroundColor(Color.GREEN)
            "b"-> quizBinding.textViewB.setBackgroundColor(Color.GREEN)
            "c"-> quizBinding.textViewC.setBackgroundColor(Color.GREEN)
            "d"-> quizBinding.textViewD.setBackgroundColor(Color.GREEN)
        }
    }
fun disableClickableOfOptions(){
    quizBinding.textViewA.isClickable=false
    quizBinding.textViewB.isClickable=false
    quizBinding.textViewC.isClickable=false
    quizBinding.textViewD.isClickable=false

}
    fun restoreOptions(){
        quizBinding.textViewA.setBackgroundColor(Color.WHITE)
        quizBinding.textViewB.setBackgroundColor(Color.WHITE)
        quizBinding.textViewC.setBackgroundColor(Color.WHITE)
        quizBinding.textViewD.setBackgroundColor(Color.WHITE)

        quizBinding.textViewA.isClickable=true
        quizBinding.textViewB.isClickable=true
        quizBinding.textViewC.isClickable=true
        quizBinding.textViewD.isClickable=true

    }
    private  fun startTimer() {
        timer = object : CountDownTimer(timeLeft, 1000){
            override fun onTick(millisUntilFinished: Long) {
                timeLeft=millisUntilFinished
                updateCountDownText()

            }

            override fun onFinish() {
                disableClickableOfOptions()
                resetTimer()
                updateCountDownText()
                quizBinding.textViewQuestion.text="Sorry, Time is up! Continue with next question."
                timeContinue=false
            }

        }.start()
        timeContinue=true

    }
    fun updateCountDownText(){
        val remainingTime = (timeLeft/1000).toInt()
        quizBinding.textViewTime.text=remainingTime.toString()

    }
    fun pauseTimer(){
        timer.cancel()
        timeContinue=false

    }
    fun resetTimer(){
        pauseTimer()
        timeLeft=totalTime
        updateCountDownText()

    }
    fun sendScore(){
        user?.let {
            val userUID = it.uid
            scoreRef.child("scores").child(userUID).child("correct").setValue(userCorrect)
            scoreRef.child("scores").child(userUID).child("wrong").setValue(userWrong).addOnSuccessListener {
                Toast.makeText(this, "Score saved", Toast.LENGTH_SHORT).show()
                val intent = Intent(this@QuizActivity, ResultActivity::class.java)
                startActivity(intent)
                finish()
            }
        }

    }
}
