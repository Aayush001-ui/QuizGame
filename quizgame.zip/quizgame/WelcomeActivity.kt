package com.techmania.quizgame

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.AnimationUtils
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.techmania.quizgame.databinding.ActivityWelcomeBinding

class WelcomeActivity : AppCompatActivity() {

    lateinit var splashbinding: ActivityWelcomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        splashbinding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(splashbinding.root)
        enableEdgeToEdge()
        setContentView(R.layout.activity_welcome)
        val alphaAnimation= AnimationUtils.loadAnimation(applicationContext,R.anim.splash_anim)
        splashbinding.textViewSplash.startAnimation(alphaAnimation)
        val handler=Handler(Looper.getMainLooper())
        handler.postDelayed(object :Runnable {
            override fun run() {
                val intent= Intent(this@WelcomeActivity,LoginActivity::class.java)
                startActivity(intent)
                finish()
            }
        }, 5000)

    }
}